// Importar express
const express = require('express');
const app = express();
const port = 3000;

// Middleware para interpretar JSON
app.use(express.json());

// Ruta de prueba
app.get('/', (req, res) => {
  res.send('API Autonova funcionando 🚀');
});

// Otra ruta ejemplo
app.get('/api/vehiculos', (req, res) => {
  res.json([
    { id: 1, marca: 'Toyota', modelo: 'Corolla' },
    { id: 2, marca: 'Mazda', modelo: 'CX-5' }
  ]);
});

// Iniciar servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
